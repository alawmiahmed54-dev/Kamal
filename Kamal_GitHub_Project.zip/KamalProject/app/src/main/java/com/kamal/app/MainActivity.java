package com.kamal.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int PICK_IMPORT = 41, PICK_EXPORT = 42;
    private LinearLayout root, content;
    private TextView status;
    private File importsDir, answersDir;
    private String currentKey = "";
    private WebView editor;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        importsDir = new File(getFilesDir(), "imports"); importsDir.mkdirs();
        answersDir = new File(getFilesDir(), "answers"); answersDir.mkdirs();
        showHome();
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v -> action.run()); return b;
    }
    private void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247,249,252));
        TextView head = text("كمال  |  Kamal", 23, Color.WHITE); head.setTypeface(null, Typeface.BOLD); head.setPadding(18,8,18,8); head.setBackgroundColor(Color.rgb(26,77,99)); head.setMinHeight(62); root.addView(head);
        TextView sub = text(title, 16, Color.rgb(26,77,99)); sub.setPadding(16,10,16,4); root.addView(sub);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setPadding(14,8,14,20); content.setOrientation(LinearLayout.VERTICAL); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        status = text("البيانات محفوظة محلياً على هذا الهاتف", 12, Color.DKGRAY); status.setPadding(14,8,14,8); root.addView(status); setContentView(root);
    }
    private void showHome() {
        base("إدارة التكليفات");
        content.addView(button("＋ استيراد ملف EXMZ أو ZIP", this::pickImport));
        content.addView(button("تصدير نسخة احتياطية من كمال", this::pickExport));
        TextView note = text("مهم: النسخة الحالية تحفظ الملفات الأصلية دون تعديل وتتيح حفظ الإجابات محلياً. توافق التصدير مع منصة الجامعة لم يُثبت بعد.", 14, Color.rgb(120,70,20)); note.setPadding(8,12,8,12); content.addView(note);
        File[] dirs = importsDir.listFiles(File::isDirectory);
        if (dirs == null || dirs.length == 0) { content.addView(text("لا توجد ملفات مستوردة بعد. اختر ملف الجامعة للبدء.", 16, Color.DKGRAY)); return; }
        content.addView(text("الملفات المستوردة", 19, Color.rgb(26,77,99)));
        for (File d : dirs) { content.addView(button("📁 " + d.getName(), () -> showArchive(d))); }
    }
    private void pickImport() { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i, PICK_IMPORT); }
    private void pickExport() { Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); i.putExtra(Intent.EXTRA_TITLE, "Kamal_Backup.zip"); startActivityForResult(i, PICK_EXPORT); }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data); if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { if (req == PICK_IMPORT) { String name = new File(uri.getLastPathSegment() == null ? "import" : uri.getLastPathSegment()).getName(); importZip(uri, safeName(name)); showHome(); }
            else if (req == PICK_EXPORT) exportBackup(uri);
        } catch(Exception e) { status.setText("تعذر إكمال العملية: " + e.getMessage()); }
    }
    private String safeName(String s) { s = s.replaceAll("[^A-Za-z0-9._-]", "_"); if (s.length() > 40) s=s.substring(s.length()-40); return System.currentTimeMillis()+"_"+s; }
    private void importZip(Uri uri, String name) throws Exception {
        File target = new File(importsDir, name); target.mkdirs();
        try (InputStream in = getContentResolver().openInputStream(uri); ZipInputStream zis = new ZipInputStream(new BufferedInputStream(in))) {
            ZipEntry e; int count=0;
            while ((e=zis.getNextEntry())!=null) {
                String n=e.getName().replace('\\','/'); if(n.startsWith("/") || n.contains("../") || n.equals("..")) throw new IOException("مسار غير آمن داخل الأرشيف");
                File out=new File(target,n); String base=target.getCanonicalPath()+File.separator;
                if(!out.getCanonicalPath().startsWith(base)) throw new IOException("مسار غير آمن");
                if(e.isDirectory()) out.mkdirs(); else { File parent=out.getParentFile(); if(parent!=null) parent.mkdirs(); try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))) { byte[] buf=new byte[8192]; int r; while((r=zis.read(buf))!=-1) os.write(buf,0,r); } count++; }
                zis.closeEntry();
            }
            if(count==0) throw new IOException("لم يتم العثور على ملفات ZIP؛ تأكد أن الملف EXMZ/ZIP صالح");
        }
    }
    private void showArchive(File dir) {
        base("محتويات: " + dir.getName()); content.addView(button("← رجوع", this::showHome));
        java.util.ArrayList<File> files = new java.util.ArrayList<>(); collect(dir, files);
        for(File f: files) { String rel=dir.toURI().relativize(f.toURI()).getPath();
            if(rel.endsWith(".metadata") || rel.endsWith(".lock")) content.addView(text("ملف بيانات: "+rel,13,Color.GRAY));
            else if(rel.startsWith("assessments/")) content.addView(button("فتح / تحرير إجابة: "+rel, () -> openEditor(dir,rel)));
            else content.addView(text("• "+rel,13,Color.DKGRAY));
        }
        if(files.isEmpty()) content.addView(text("لا توجد ملفات داخل هذا الأرشيف",16,Color.DKGRAY));
    }
    private void collect(File d, java.util.List<File> out) { File[] fs=d.listFiles(); if(fs==null)return; for(File f:fs) if(f.isDirectory())collect(f,out); else out.add(f); }
    private String keyFor(File dir, String rel) { return (dir.getName()+"__"+rel).replaceAll("[^A-Za-z0-9._-]","_"); }
    private void openEditor(File dir, String rel) {
        currentKey=keyFor(dir,rel); base("محرر الإجابة");
        content.addView(text(rel,13,Color.GRAY)); content.addView(text("الإجابة محفوظة في مساحة كمال المحلية، ولا تُحقن في ملف الجامعة الأصلي لأن مخطط الإجابات لم يُثبت بعد.",13,Color.rgb(120,70,20)));
        editor=new WebView(this); editor.getSettings().setJavaScriptEnabled(true); editor.getSettings().setDomStorageEnabled(true); editor.setWebChromeClient(new WebChromeClient()); editor.setWebViewClient(new WebViewClient()); editor.addJavascriptInterface(new Bridge(),"Kamal");
        String saved=""; File sf=new File(answersDir,currentKey+".html"); if(sf.exists()) try { saved=read(sf); } catch(Exception ignored){}
        String html="<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><script src='file:///android_asset/tinymce/tinymce.min.js'></script><style>body{font-family:Arial,sans-serif;padding:8px}#ed{min-height:65vh}</style></head><body dir='rtl'><textarea id='ed'></textarea><script>const initial="+JSONObject.quote(saved)+";tinymce.init({selector:'#ed',height:'65vh',menubar:'edit view insert format table',plugins:'lists table image link code directionality',toolbar:'undo redo | blocks | bold italic underline | alignleft aligncenter alignright | bullist numlist | table | ltr rtl | link image | code',language:'ar',directionality:'rtl',setup:function(ed){ed.on('init',()=>{ed.setContent(initial);});ed.on('input change keyup undo redo',()=>Kamal.save(ed.getContent()));}});</script></body></html>";
        editor.loadDataWithBaseURL("file:///android_asset/",html,"text/html","UTF-8",null); content.addView(editor,new LinearLayout.LayoutParams(-1,0,1)); content.addView(button("حفظ الآن", () -> { if(editor!=null) editor.evaluateJavascript("Kamal.save(tinymce.activeEditor.getContent())",null); status.setText("تم طلب حفظ الإجابة محلياً"); })); content.addView(button("العودة إلى الملفات", () -> showArchive(dir)));
    }
    private String read(File f) throws Exception { ByteArrayOutputStream b=new ByteArrayOutputStream(); try(InputStream in=new FileInputStream(f)){byte[] x=new byte[8192];int n;while((n=in.read(x))>0)b.write(x,0,n);} return b.toString("UTF-8"); }
    private class Bridge { @JavascriptInterface public void save(String html) { try { File f=new File(answersDir,currentKey+".html"); try(OutputStream o=new FileOutputStream(f)){o.write(html.getBytes(StandardCharsets.UTF_8));} } catch(Exception ignored){} } }
    private void exportBackup(Uri uri) throws Exception {
        try(OutputStream raw=getContentResolver().openOutputStream(uri); ZipOutputStream zos=new ZipOutputStream(new BufferedOutputStream(raw))) {
            zipFolder(importsDir,"imports",zos); zipFolder(answersDir,"answers",zos);
            zos.putNextEntry(new ZipEntry("README_KAMAL_BACKUP.txt")); zos.write("Kamal local backup. This is NOT a verified university-compatible export. Original imported files are preserved under imports/; editor answers are stored separately under answers/ and have not been injected into the university file format.".getBytes(StandardCharsets.UTF_8)); zos.closeEntry();
        }
        status.setText("اكتمل إنشاء نسخة كمال الاحتياطية. ليست صيغة تصدير جامعية مؤكدة.");
    }
    private void zipFolder(File dir,String prefix,ZipOutputStream zos) throws Exception { File[] fs=dir.listFiles(); if(fs==null)return; for(File f:fs){String p=prefix+"/"+f.getName(); if(f.isDirectory())zipFolder(f,p,zos); else {zos.putNextEntry(new ZipEntry(p));try(InputStream in=new FileInputStream(f)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)zos.write(b,0,n);}zos.closeEntry();}} }
}
